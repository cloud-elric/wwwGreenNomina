<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=nomina_posada',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
